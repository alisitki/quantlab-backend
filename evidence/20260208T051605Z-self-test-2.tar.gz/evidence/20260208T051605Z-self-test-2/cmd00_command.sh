bash -lc echo\ hi\;\ echo\ err\ \>\&2
