# Evidence Pack: 20260208T051620Z-self-test-3

Commands index (root cmd*.sh):
- cmd00_command.sh

Command directories (root cmd*/):
- cmd00_command/

Notes: This pack was normalized to the standard layout; some legacy items may not include full /usr/bin/time -v or exit codes.
