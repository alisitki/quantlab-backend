# Evidence Pack: sprint4-acceptance-closeout-20260208

Commands index (root cmd*.sh):
- cmd00_precheck_repo_and_bins.sh
- cmd01_runner_help.sh
- cmd02b_runA_default_on_acceptance_exitcodefix.sh
- cmd02d_runA_default_on_acceptance_exitcodefix2.sh
- cmd02_runA_default_on_acceptance.sh
- cmd03b_runB_off_acceptance_exitcodefix.sh
- cmd03d_runB_off_acceptance_exitcodefix2.sh
- cmd03_runB_off_acceptance.sh
- cmd04b_runA_default_on_acceptance_2days_exitcodefix.sh
- cmd04_runA2_default_on_acceptance_2days.sh
- cmd05b_runB_off_acceptance_2days_exitcodefix.sh
- cmd05_runB2_off_acceptance_2days.sh
- cmd06b_compare_exitcodefix.sh
- cmd06_compare.sh

Command directories (root cmd*/):
- cmd00_precheck_repo_and_bins/
- cmd01_runner_help/
- cmd02b_runA_default_on_acceptance_exitcodefix/
- cmd02d_runA_default_on_acceptance_exitcodefix2/
- cmd02_runA_default_on_acceptance/
- cmd03b_runB_off_acceptance_exitcodefix/
- cmd03d_runB_off_acceptance_exitcodefix2/
- cmd03_runB_off_acceptance/
- cmd04b_runA_default_on_acceptance_2days_exitcodefix/
- cmd04_runA2_default_on_acceptance_2days/
- cmd05b_runB_off_acceptance_2days_exitcodefix/
- cmd05_runB2_off_acceptance_2days/
- cmd06b_compare_exitcodefix/
- cmd06_compare/

Notes: This pack was normalized to the standard layout; some legacy items may not include full /usr/bin/time -v or exit codes.
