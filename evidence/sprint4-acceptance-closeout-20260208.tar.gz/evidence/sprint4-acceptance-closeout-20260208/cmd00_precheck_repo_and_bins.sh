#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd00_precheck_repo_and_bins/stdout.log cmd00_precheck_repo_and_bins/stderr.log cmd00_precheck_repo_and_bins/time_v.log cmd00_precheck_repo_and_bins/exit_code.txt (if present)
