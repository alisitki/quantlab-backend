#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd02_runA_default_on_acceptance/stdout.log cmd02_runA_default_on_acceptance/stderr.log cmd02_runA_default_on_acceptance/time_v.log cmd02_runA_default_on_acceptance/exit_code.txt (if present)
