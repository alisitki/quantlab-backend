#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd02b_runA_default_on_acceptance_exitcodefix/stdout.log cmd02b_runA_default_on_acceptance_exitcodefix/stderr.log cmd02b_runA_default_on_acceptance_exitcodefix/time_v.log cmd02b_runA_default_on_acceptance_exitcodefix/exit_code.txt (if present)
