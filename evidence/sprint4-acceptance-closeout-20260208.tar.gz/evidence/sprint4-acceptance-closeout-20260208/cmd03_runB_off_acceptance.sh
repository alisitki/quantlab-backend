#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd03_runB_off_acceptance/stdout.log cmd03_runB_off_acceptance/stderr.log cmd03_runB_off_acceptance/time_v.log cmd03_runB_off_acceptance/exit_code.txt (if present)
