#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd03b_runB_off_acceptance_exitcodefix/stdout.log cmd03b_runB_off_acceptance_exitcodefix/stderr.log cmd03b_runB_off_acceptance_exitcodefix/time_v.log cmd03b_runB_off_acceptance_exitcodefix/exit_code.txt (if present)
