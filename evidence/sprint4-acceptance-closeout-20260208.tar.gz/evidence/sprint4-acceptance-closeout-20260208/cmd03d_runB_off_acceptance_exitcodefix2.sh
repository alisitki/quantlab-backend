#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd03d_runB_off_acceptance_exitcodefix2/stdout.log cmd03d_runB_off_acceptance_exitcodefix2/stderr.log cmd03d_runB_off_acceptance_exitcodefix2/time_v.log cmd03d_runB_off_acceptance_exitcodefix2/exit_code.txt (if present)
