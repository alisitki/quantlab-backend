#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd04b_runA_default_on_acceptance_2days_exitcodefix/stdout.log cmd04b_runA_default_on_acceptance_2days_exitcodefix/stderr.log cmd04b_runA_default_on_acceptance_2days_exitcodefix/time_v.log cmd04b_runA_default_on_acceptance_2days_exitcodefix/exit_code.txt (if present)
