#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd05_runB2_off_acceptance_2days/stdout.log cmd05_runB2_off_acceptance_2days/stderr.log cmd05_runB2_off_acceptance_2days/time_v.log cmd05_runB2_off_acceptance_2days/exit_code.txt (if present)
