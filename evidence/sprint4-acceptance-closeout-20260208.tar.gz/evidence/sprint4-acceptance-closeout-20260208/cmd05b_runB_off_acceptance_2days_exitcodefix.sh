#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd05b_runB_off_acceptance_2days_exitcodefix/stdout.log cmd05b_runB_off_acceptance_2days_exitcodefix/stderr.log cmd05b_runB_off_acceptance_2days_exitcodefix/time_v.log cmd05b_runB_off_acceptance_2days_exitcodefix/exit_code.txt (if present)
