#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd06_compare/stdout.log cmd06_compare/stderr.log cmd06_compare/time_v.log cmd06_compare/exit_code.txt (if present)
