#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd06b_compare_exitcodefix/stdout.log cmd06b_compare_exitcodefix/stderr.log cmd06b_compare_exitcodefix/time_v.log cmd06b_compare_exitcodefix/exit_code.txt (if present)
