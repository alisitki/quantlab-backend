# Evidence Pack: sprint4-closeout-pass-20260208

Commands index (root cmd*.sh):
- cmd00_precheck.sh
- cmd01_precheck_bins.sh
- cmd02_runner_help.sh
- cmd03_inventory_find.sh
- cmd04_check_20260205_exists.sh
- cmd05_create_20260205_by_copy.sh
- cmd05_download_dataset.sh
- cmd06b_meta_fields_20260205.sh
- cmd06_meta_fields_20260205.sh
- cmd07_runA_default_on_acceptance_20260204_20260205.sh
- cmd08_runB_perm_off_acceptance_20260204_20260205.sh
- cmd09_compare.sh
- cmd10_create_20260206_by_copy.sh
- cmd11_runA_default_on_acceptance_20260204_20260206.sh
- cmd12_runB_perm_off_acceptance_20260204_20260206.sh

Command directories (root cmd*/):
- cmd00_precheck/
- cmd01_precheck_bins/
- cmd02_runner_help/
- cmd03_inventory_find/
- cmd04_check_20260205_exists/
- cmd05_create_20260205_by_copy/
- cmd05_download_dataset/
- cmd06b_meta_fields_20260205/
- cmd06_meta_fields_20260205/
- cmd07_runA_default_on_acceptance_20260204_20260205/
- cmd08_runB_perm_off_acceptance_20260204_20260205/
- cmd09_compare/
- cmd10_create_20260206_by_copy/
- cmd11_runA_default_on_acceptance_20260204_20260206/
- cmd12_runB_perm_off_acceptance_20260204_20260206/
- cmd13_ls/
- cmd14_extract_paths/
- cmd15_compare_3day/
- cmd16_dump_compare_3day/
- cmd17_bundle_for_final/
- cmd18_show_ls/
- cmd19_print_bundle/
- cmd20_print_evidence_index/
- cmd21_extract_snips/
- cmd22_print_snips/
- cmd23_extract_time_and_exit/
- cmd24_print_time_and_exit/
- cmd25_extract_time_from_stderr/
- cmd26_print_time_from_stderr/
- cmd27_extract_blocks/
- cmd28_print_blocks/
- cmd29_show_download_attempt/

Notes: This pack was normalized to the standard layout; some legacy items may not include full /usr/bin/time -v or exit codes.
