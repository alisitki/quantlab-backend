#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd00_precheck/stdout.log cmd00_precheck/stderr.log cmd00_precheck/time_v.log cmd00_precheck/exit_code.txt (if present)
