#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd01_precheck_bins/stdout.log cmd01_precheck_bins/stderr.log cmd01_precheck_bins/time_v.log cmd01_precheck_bins/exit_code.txt (if present)
