#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd02_runner_help/stdout.log cmd02_runner_help/stderr.log cmd02_runner_help/time_v.log cmd02_runner_help/exit_code.txt (if present)
