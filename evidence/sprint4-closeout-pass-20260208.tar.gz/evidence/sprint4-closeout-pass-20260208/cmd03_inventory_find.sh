#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd03_inventory_find/stdout.log cmd03_inventory_find/stderr.log cmd03_inventory_find/time_v.log cmd03_inventory_find/exit_code.txt (if present)
