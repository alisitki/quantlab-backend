#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd04_check_20260205_exists/stdout.log cmd04_check_20260205_exists/stderr.log cmd04_check_20260205_exists/time_v.log cmd04_check_20260205_exists/exit_code.txt (if present)
