#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd05_create_20260205_by_copy/stdout.log cmd05_create_20260205_by_copy/stderr.log cmd05_create_20260205_by_copy/time_v.log cmd05_create_20260205_by_copy/exit_code.txt (if present)
