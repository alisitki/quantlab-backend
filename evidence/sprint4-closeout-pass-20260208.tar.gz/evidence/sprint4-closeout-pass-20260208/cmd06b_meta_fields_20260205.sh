#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd06b_meta_fields_20260205/stdout.log cmd06b_meta_fields_20260205/stderr.log cmd06b_meta_fields_20260205/time_v.log cmd06b_meta_fields_20260205/exit_code.txt (if present)
