#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd07_runA_default_on_acceptance_20260204_20260205/stdout.log cmd07_runA_default_on_acceptance_20260204_20260205/stderr.log cmd07_runA_default_on_acceptance_20260204_20260205/time_v.log cmd07_runA_default_on_acceptance_20260204_20260205/exit_code.txt (if present)
