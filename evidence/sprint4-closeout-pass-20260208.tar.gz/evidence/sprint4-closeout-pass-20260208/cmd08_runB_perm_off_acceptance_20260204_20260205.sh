#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd08_runB_perm_off_acceptance_20260204_20260205/stdout.log cmd08_runB_perm_off_acceptance_20260204_20260205/stderr.log cmd08_runB_perm_off_acceptance_20260204_20260205/time_v.log cmd08_runB_perm_off_acceptance_20260204_20260205/exit_code.txt (if present)
