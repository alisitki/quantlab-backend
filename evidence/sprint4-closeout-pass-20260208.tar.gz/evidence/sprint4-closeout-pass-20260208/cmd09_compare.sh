#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd09_compare/stdout.log cmd09_compare/stderr.log cmd09_compare/time_v.log cmd09_compare/exit_code.txt (if present)
