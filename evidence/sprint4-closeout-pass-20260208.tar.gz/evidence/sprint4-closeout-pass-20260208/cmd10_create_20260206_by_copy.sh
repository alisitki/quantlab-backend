#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd10_create_20260206_by_copy/stdout.log cmd10_create_20260206_by_copy/stderr.log cmd10_create_20260206_by_copy/time_v.log cmd10_create_20260206_by_copy/exit_code.txt (if present)
