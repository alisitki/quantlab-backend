#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd11_runA_default_on_acceptance_20260204_20260206/stdout.log cmd11_runA_default_on_acceptance_20260204_20260206/stderr.log cmd11_runA_default_on_acceptance_20260204_20260206/time_v.log cmd11_runA_default_on_acceptance_20260204_20260206/exit_code.txt (if present)
