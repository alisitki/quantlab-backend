#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd12_runB_perm_off_acceptance_20260204_20260206/stdout.log cmd12_runB_perm_off_acceptance_20260204_20260206/stderr.log cmd12_runB_perm_off_acceptance_20260204_20260206/time_v.log cmd12_runB_perm_off_acceptance_20260204_20260206/exit_code.txt (if present)
