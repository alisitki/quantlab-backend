# Evidence Pack: sprint4-closeout-real2day-20260208

Commands index (root cmd*.sh):
- cmd00_pwd.sh
- cmd01_bins.sh
- cmd02_runner_help.sh
- cmd03_find_data_all.sh
- cmd04_list_adausdt_days.sh
- cmd05_meta_fields_sprint2_20260110.sh
- cmd06_meta_fields_sprint2_20260111.sh
- cmd07_runA1_default_on_acceptance_20260110_20260111.sh
- cmd08_inspect_runA1_sprint2.sh
- cmd09_runA1_default_on_acceptance_20260203_20260204.sh
- cmd10_runA2_default_on_acceptance_20260203_20260204.sh
- cmd13_compare_on_vs_on_20260203_20260204.sh
- cmd14_runB1_perm_off_acceptance_20260203_20260204.sh
- cmd15_runB2_perm_off_acceptance_20260203_20260204.sh
- cmd16_compare_off_vs_off_20260203_20260204.sh

Command directories (root cmd*/):
- cmd00_pwd/
- cmd01_bins/
- cmd02_runner_help/
- cmd03_find_data_all/
- cmd04_list_adausdt_days/
- cmd05_meta_fields_sprint2_20260110/
- cmd06_meta_fields_sprint2_20260111/
- cmd07_runA1_default_on_acceptance_20260110_20260111/
- cmd08_inspect_runA1_sprint2/
- cmd09_runA1_default_on_acceptance_20260203_20260204/
- cmd10_runA2_default_on_acceptance_20260203_20260204/
- cmd13_compare_on_vs_on_20260203_20260204/
- cmd14_runB1_perm_off_acceptance_20260203_20260204/
- cmd15_runB2_perm_off_acceptance_20260203_20260204/
- cmd16_compare_off_vs_off_20260203_20260204/
- cmd17_extract_streaming_files/
- cmd18_collect_cmds/

Notes: This pack was normalized to the standard layout; some legacy items may not include full /usr/bin/time -v or exit codes.
