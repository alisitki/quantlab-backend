node tools/run-multi-day-discovery.js --help
