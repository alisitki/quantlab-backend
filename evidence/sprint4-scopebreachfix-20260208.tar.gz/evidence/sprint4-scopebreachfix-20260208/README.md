# Evidence Pack: sprint4-scopebreachfix-20260208

Commands index (root cmd*.sh):
- cmd00_manual.sh

Command directories (root cmd*/):
- cmd00_manual/

Notes: This pack was normalized to the standard layout; some legacy items may not include full /usr/bin/time -v or exit codes.
