# Evidence Pack: sprint5-acceptance-real2day-20260204-20260205-20260209

Purpose: Sprint-5 acceptance closeout evidence (real 2-day window + determinism compares).

Verify bar:
- Acceptance runs: EXIT=0, patterns_scanned>0, edges_saved present (see cmd16..cmd19 outputs)
- Determinism: ON vs ON PASS and OFF vs OFF PASS (see cmd20/cmd21 outputs)
- Real-day proof: meta sha256 differs (see sha256/)

Risk note: Inputs are labeled day_quality=DIAGNOSTIC_SLICE (10-minute slice).

Inputs:
- inputs/
- sha256/

Commands index:
- cmd00_packaging_exists_check
- cmd01_packaging_exists_src_evidence
- cmd02_packaging_copy_inputs_and_sha
- cmd03_packaging_copy_runs
- cmd04_packaging_write_summary_json
- cmd05_packaging_write_readme
- cmd06_packaging_tree
- cmd07_packaging_show_summary
- cmd08_finalize_ls_runs_B2
- cmd09_finalize_cat_readme
- cmd10_finalize_cat_summary
- cmd11_finalize_ls_runs_all
- cmd12_finalize_show_readme_after
- cmd13_finalize_show_summary_after
- cmd14_finalize_integrity_check
- cmd15_finalize_before_after_snips
- cmd16_accept_A1_default_on_20260204_20260205
- cmd17_accept_A2_default_on_20260204_20260205
- cmd18_accept_B1_perm_off_20260204_20260205
- cmd19_accept_B2_perm_off_20260204_20260205
- cmd20_compare_on_vs_on_20260204_20260205
- cmd21_compare_off_vs_off_20260204_20260205

Key outputs:
- summary.json
