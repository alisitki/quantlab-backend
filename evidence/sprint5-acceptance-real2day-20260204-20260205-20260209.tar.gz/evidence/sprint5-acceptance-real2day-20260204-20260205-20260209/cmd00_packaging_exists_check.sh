set -euo pipefail
files=(
  runs/multi-day-discovery/2026-02-09T05-02-48-847Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/discovery-report-2026-02-09T05-02-48-847Z.json
  runs/multi-day-discovery/2026-02-09T05-02-48-847Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/edges-discovered-2026-02-09T05-02-48-847Z.json
  runs/multi-day-discovery/2026-02-09T05-03-08-867Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/discovery-report-2026-02-09T05-03-08-867Z.json
  runs/multi-day-discovery/2026-02-09T05-03-08-867Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/edges-discovered-2026-02-09T05-03-08-867Z.json
  runs/multi-day-discovery/2026-02-09T05-03-30-163Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/discovery-report-2026-02-09T05-03-30-163Z.json
  runs/multi-day-discovery/2026-02-09T05-03-30-163Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/edges-discovered-2026-02-09T05-03-30-163Z.json
  runs/multi-day-discovery/2026-02-09T05-03-49-126Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/discovery-report-2026-02-09T05-03-49-126Z.json
  runs/multi-day-discovery/2026-02-09T05-03-49-126Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/edges-discovered-2026-02-09T05-03-49-126Z.json
)
for f in "${files[@]}"; do
  if [ -f "$f" ]; then echo "OK $f"; else echo "MISSING $f"; fi
 done
