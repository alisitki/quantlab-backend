set -euo pipefail
for d in \
  cmd55_accept_A1_default_on_20260204_20260205 \
  cmd56_accept_A2_default_on_20260204_20260205 \
  cmd57_accept_B1_perm_off_20260204_20260205 \
  cmd58_accept_B2_perm_off_20260204_20260205 \
  cmd59_compare_ON_vs_ON_20260204_20260205 \
  cmd60_compare_OFF_vs_OFF_20260204_20260205 \
  cmd53_verify_real_window_sha_diff_20260204_20260205 \
; do
  test -d "evidence/sprint5-kickoff-real2day-nonzero-20260208/$d" && echo "OK dir=$d" || echo "MISSING dir=$d"
  for f in cmd.sh stdout.log stderr.log time-v.log exit_code.txt; do
    test -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/$d/$f" && : || echo "MISSING file=$d/$f"
  done
 done
