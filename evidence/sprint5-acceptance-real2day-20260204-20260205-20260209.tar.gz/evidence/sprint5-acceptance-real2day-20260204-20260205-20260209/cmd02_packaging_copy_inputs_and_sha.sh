set -euo pipefail
mkdir -p "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/inputs" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/sha256"
cp -f data/test/adausdt_20260204.parquet "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/inputs/"
cp -f data/test/adausdt_20260204_meta.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/inputs/"
cp -f data/test/adausdt_20260205.parquet "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/inputs/"
cp -f data/test/adausdt_20260205_meta.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/inputs/"

( cd "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/inputs" && sha256sum adausdt_20260204.parquet adausdt_20260205.parquet ) | tee "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/sha256/sha256sum_inputs_parquet.txt"

node - <<"NODE" | tee "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/sha256/meta_sha256_proof.txt"
import { readFileSync } from "node:fs";
const m04 = JSON.parse(readFileSync("data/test/adausdt_20260204_meta.json","utf8"));
const m05 = JSON.parse(readFileSync("data/test/adausdt_20260205_meta.json","utf8"));
console.log(`20260204.sha256=${m04.sha256}`);
console.log(`20260205.sha256=${m05.sha256}`);
console.log(`sha_equal=${String(m04.sha256===m05.sha256)}`);
console.log(`20260204.rows=${m04.rows}`);
console.log(`20260205.rows=${m05.rows}`);
console.log(`20260204.day_quality=${m04.day_quality}`);
console.log(`20260205.day_quality=${m05.day_quality}`);
NODE
