set -euo pipefail
mkdir -p "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/on_vs_on" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/off_vs_off"

# Reports/edges copies
cp -f runs/multi-day-discovery/2026-02-09T05-02-48-847Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/discovery-report-2026-02-09T05-02-48-847Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1/"
cp -f runs/multi-day-discovery/2026-02-09T05-02-48-847Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/edges-discovered-2026-02-09T05-02-48-847Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1/"

cp -f runs/multi-day-discovery/2026-02-09T05-03-08-867Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/discovery-report-2026-02-09T05-03-08-867Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2/"
cp -f runs/multi-day-discovery/2026-02-09T05-03-08-867Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/edges-discovered-2026-02-09T05-03-08-867Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2/"

cp -f runs/multi-day-discovery/2026-02-09T05-03-30-163Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/discovery-report-2026-02-09T05-03-30-163Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1/"
cp -f runs/multi-day-discovery/2026-02-09T05-03-30-163Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/edges-discovered-2026-02-09T05-03-30-163Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1/"

cp -f runs/multi-day-discovery/2026-02-09T05-03-49-126Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/discovery-report-2026-02-09T05-03-49-126Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2/"
cp -f runs/multi-day-discovery/2026-02-09T05-03-49-126Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-off/edges-discovered-2026-02-09T05-03-49-126Z.json "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2/"

# Runner logs (/usr/bin/time -v, stdout/stderr, command)
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd55_accept_A1_default_on_20260204_20260205/cmd.sh" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd55_accept_A1_default_on_20260204_20260205/stdout.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd55_accept_A1_default_on_20260204_20260205/stderr.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd55_accept_A1_default_on_20260204_20260205/time-v.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd55_accept_A1_default_on_20260204_20260205/exit_code.txt" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A1/"

cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd56_accept_A2_default_on_20260204_20260205/cmd.sh" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd56_accept_A2_default_on_20260204_20260205/stdout.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd56_accept_A2_default_on_20260204_20260205/stderr.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd56_accept_A2_default_on_20260204_20260205/time-v.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd56_accept_A2_default_on_20260204_20260205/exit_code.txt" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/A2/"

cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd57_accept_B1_perm_off_20260204_20260205/cmd.sh" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd57_accept_B1_perm_off_20260204_20260205/stdout.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd57_accept_B1_perm_off_20260204_20260205/stderr.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd57_accept_B1_perm_off_20260204_20260205/time-v.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd57_accept_B1_perm_off_20260204_20260205/exit_code.txt" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B1/"

cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd58_accept_B2_perm_off_20260204_20260205/cmd.sh" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd58_accept_B2_perm_off_20260204_20260205/stdout.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd58_accept_B2_perm_off_20260204_20260205/stderr.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd58_accept_B2_perm_off_20260204_20260205/time-v.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd58_accept_B2_perm_off_20260204_20260205/exit_code.txt" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/runs/B2/"

# Determinism compare logs
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd59_compare_ON_vs_ON_20260204_20260205/cmd.sh" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/on_vs_on/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd59_compare_ON_vs_ON_20260204_20260205/stdout.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/on_vs_on/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd59_compare_ON_vs_ON_20260204_20260205/stderr.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/on_vs_on/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd59_compare_ON_vs_ON_20260204_20260205/time-v.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/on_vs_on/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd59_compare_ON_vs_ON_20260204_20260205/exit_code.txt" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/on_vs_on/"

cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd60_compare_OFF_vs_OFF_20260204_20260205/cmd.sh" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/off_vs_off/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd60_compare_OFF_vs_OFF_20260204_20260205/stdout.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/off_vs_off/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd60_compare_OFF_vs_OFF_20260204_20260205/stderr.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/off_vs_off/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd60_compare_OFF_vs_OFF_20260204_20260205/time-v.log" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/off_vs_off/"
cp -f "evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd60_compare_OFF_vs_OFF_20260204_20260205/exit_code.txt" "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/determinism/off_vs_off/"
