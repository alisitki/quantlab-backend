node - <<"NODE"
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const outDir = "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209";

function readJSON(p){ return JSON.parse(readFileSync(p,"utf8")); }

function parseTimeV(p){
  const t = readFileSync(p,"utf8");
  const elapsed = t.match(/Elapsed \(wall clock\) time \(h:mm:ss or m:ss\):\s*([0-9:]+\.[0-9]+|[0-9:]+)/)?.[1] ?? null;
  const maxrss = t.match(/Maximum resident set size \(kbytes\):\s*(\d+)/)?.[1] ?? null;
  const exitStatus = t.match(/Exit status:\s*(\d+)/)?.[1] ?? null;
  function toSeconds(s){
    if (!s) return null;
    // Formats seen: m:ss.xx, h:mm:ss.xx, or 0:00.07
    const parts = s.split(":");
    if (parts.length === 1) return Number(parts[0]);
    if (parts.length === 2) return Number(parts[0])*60 + Number(parts[1]);
    if (parts.length === 3) return Number(parts[0])*3600 + Number(parts[1])*60 + Number(parts[2]);
    return null;
  }
  return {
    elapsed_raw: elapsed,
    wall_s: toSeconds(elapsed),
    max_rss_kb: maxrss ? Number(maxrss) : null,
    time_exit_status: exitStatus ? Number(exitStatus) : null,
  };
}

const meta04 = readJSON("data/test/adausdt_20260204_meta.json");
const meta05 = readJSON("data/test/adausdt_20260205_meta.json");

const window = { start: "20260204", end: "20260205" };

const runs = [
  { run_id: "A1", perm_mode: "DEFAULT_ON", dir: "runs/A1" },
  { run_id: "A2", perm_mode: "DEFAULT_ON", dir: "runs/A2" },
  { run_id: "B1", perm_mode: "OFF", dir: "runs/B1" },
  { run_id: "B2", perm_mode: "OFF", dir: "runs/B2" },
];

function extractSummary(stdoutText){
  const get = (re) => stdoutText.match(re)?.[1] ?? null;
  return {
    patterns_scanned: get(/patterns_scanned:\s*(\d+)/),
    patterns_tested_significant: get(/patterns_tested_significant:\s*(\d+)/),
    edge_candidates_generated: get(/edge_candidates_generated:\s*(\d+)/),
    edge_candidates_registered: get(/edge_candidates_registered:\s*(\d+)/),
    report_saved: get(/\[Run\] report_saved=(\S+)/),
    edges_saved: get(/\[Run\] edges_saved=(\S+)/),
    exit_code: get(/> EXIT_CODE:\s*(\d+)/),
  };
}

const runMatrix = [];
for (const r of runs){
  const stdoutPath = path.join(outDir, r.dir, "stdout.log");
  const timePath = path.join(outDir, r.dir, "time-v.log");
  const cmdPath = path.join(outDir, r.dir, "cmd.sh");
  const stdout = readFileSync(stdoutPath, "utf8");
  const sum = extractSummary(stdout);
  const tv = parseTimeV(timePath);
  runMatrix.push({
    run_id: r.run_id,
    perm_mode: r.perm_mode,
    timeout_s: 1200,
    heapMB: 6144,
    exit: sum.exit_code ? Number(sum.exit_code) : null,
    patterns_scanned: sum.patterns_scanned ? Number(sum.patterns_scanned) : null,
    edges_saved: Boolean(sum.edges_saved),
    wall_s: tv.wall_s,
    max_rss_kb: tv.max_rss_kb,
    report_relpath: sum.report_saved ? sum.report_saved : null,
    edges_relpath: sum.edges_saved ? sum.edges_saved : null,
    command_relpath: path.join(r.dir, "cmd.sh"),
  });
}

const detOn = readFileSync(path.join(outDir, "determinism/on_vs_on/stdout.log"), "utf8");
const detOff = readFileSync(path.join(outDir, "determinism/off_vs_off/stdout.log"), "utf8");
const fp = detOn.match(/stable_fingerprint_sha256:\s*(\w+)/)?.[1] ?? null;

const summary = {
  window,
  inputs: {
    day1: { date: "20260204", rows: meta04.rows ?? null, sha256: meta04.sha256 ?? null, day_quality: meta04.day_quality ?? null },
    day2: { date: "20260205", rows: meta05.rows ?? null, sha256: meta05.sha256 ?? null, day_quality: meta05.day_quality ?? null },
  },
  run_matrix: runMatrix,
  determinism: {
    on_vs_on_pass: detOn.includes("COMPARE_RESULT: PASS"),
    off_vs_off_pass: detOff.includes("COMPARE_RESULT: PASS"),
    stable_fingerprint_sha256: fp,
  }
};

writeFileSync(path.join(outDir, "summary.json"), JSON.stringify(summary, null, 2) + "\n");
console.log("wrote=" + path.join(outDir, "summary.json"));
NODE
