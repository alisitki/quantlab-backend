cat > "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/README.md" <<"MD"
# Sprint-5 Acceptance Evidence Pack (Real 2-day)

## Verify Bar Checklist
- Commands: `runs/*/cmd.sh`, `determinism/*/cmd.sh`
- Critical stdout/stderr: `runs/*/stdout.log`, `runs/*/stderr.log`
- `/usr/bin/time -v`: `runs/*/time-v.log`, `determinism/*/time-v.log`
- Exit codes: `runs/*/exit_code.txt` + `runs/*/stdout.log` contains `> EXIT_CODE: ...`
- Report + edges: `runs/*/discovery-report-*.json`, `runs/*/edges-discovered-*.json`
- sha256 proof:
  - `sha256/meta_sha256_proof.txt` (includes `sha_equal=false`)
  - `sha256/sha256sum_inputs_parquet.txt`

## Window
- `20260204..20260205` (binance / bbo / ADAUSDT)

## Files
- Inputs: `inputs/`
- Runs: `runs/A1`, `runs/A2`, `runs/B1`, `runs/B2`
- Determinism: `determinism/on_vs_on`, `determinism/off_vs_off`
- Summary: `summary.json`
MD
