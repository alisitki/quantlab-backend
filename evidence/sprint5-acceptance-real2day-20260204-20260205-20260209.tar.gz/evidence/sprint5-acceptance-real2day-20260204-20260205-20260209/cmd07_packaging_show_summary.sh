cat "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209/summary.json"
