cd "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209" && ls -la runs/B2 && echo "---" && ls -1 runs/B2 | sort
