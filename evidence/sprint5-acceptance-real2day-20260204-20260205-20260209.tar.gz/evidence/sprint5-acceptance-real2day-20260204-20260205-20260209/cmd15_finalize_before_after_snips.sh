set -euo pipefail
cd "evidence/sprint5-acceptance-real2day-20260204-20260205-20260209"

echo "## BEFORE (captured) - summary.json B2 report_relpath/edges_relpath"
rg -n "\"run_id\": \"B2\"" -n "finalize/cmd02_cat_summary/stdout.log" -n || true
# Print a few lines after the match
awk "NR>=1{print}" finalize/cmd02_cat_summary/stdout.log | sed -n "1,220p" | rg -n "\"run_id\": \"B2\"|report_relpath|edges_relpath" || true

echo

echo "## AFTER - summary.json B2 report_relpath/edges_relpath"
rg -n "\"run_id\": \"B2\"|\"report_relpath\"|\"edges_relpath\"" summary.json | head -n 40 || true

echo

echo "## AFTER - determinism relpaths present"
rg -n "\"on_vs_on\"|\"off_vs_off\"|time_v_relpath|stdout_relpath|stderr_relpath|cmd_relpath|exit_code_relpath" summary.json | head -n 80 || true

echo

echo "## README now lists explicit paths (no globs)"
if rg -n "\*" README.md; then echo "README_HAS_GLOB: true"; else echo "README_HAS_GLOB: false"; fi

