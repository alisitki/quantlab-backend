ls -1 data/test/adausdt_*.parquet data/test/adausdt_*_meta.json data/sprint2/adausdt_*.parquet data/sprint2/adausdt_*_meta.json 2>/dev/null | sed -E "s#.*/##" | sort
