find data -type f \( -name "*.parquet" -o -name "*_meta.json" \) | sort
