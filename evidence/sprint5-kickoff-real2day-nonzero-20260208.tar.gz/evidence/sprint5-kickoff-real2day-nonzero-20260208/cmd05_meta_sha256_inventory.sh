node - <<"NODE"
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

function listMeta(dir){
  try { return readdirSync(dir).filter(f=>f.startsWith("adausdt_") && f.endsWith("_meta.json")); }
  catch { return []; }
}

const dirs = ["data/test", "data/sprint2"];
const rows=[];
for (const dir of dirs){
  for (const f of listMeta(dir)){
    const path = join(dir,f);
    const date = f.match(/adausdt_(\d{8})_meta\.json/)?.[1] ?? "?";
    const m = JSON.parse(readFileSync(path,"utf8"));
    rows.push({
      dir,
      date,
      rows: m.rows ?? null,
      sha256: m.sha256 ?? null,
      stream_type: m.stream_type ?? null,
      schema_version: m.schema_version ?? null,
      exchange: m.exchange ?? null,
      file: path,
    });
  }
}
rows.sort((a,b)=> (a.dir+a.date).localeCompare(b.dir+b.date));
for (const r of rows){
  console.log([r.dir,r.date,`rows=${r.rows??"N/A"}`,`sha256=${r.sha256??"N/A"}`,`stream=${r.stream_type??"N/A"}`,`schema_v=${r.schema_version??"N/A"}`,`exchange=${r.exchange??"N/A"}`].join("\t"));
}
NODE
