rg -n "DOWNLOAD_FAILED" -S tools scripts core | head
