ls -la tools
