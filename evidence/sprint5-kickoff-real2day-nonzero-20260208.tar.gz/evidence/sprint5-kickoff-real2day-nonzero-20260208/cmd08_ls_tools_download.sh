ls -1 tools | rg -n "download|s3|fetch|compact|curate|parquet" || true
