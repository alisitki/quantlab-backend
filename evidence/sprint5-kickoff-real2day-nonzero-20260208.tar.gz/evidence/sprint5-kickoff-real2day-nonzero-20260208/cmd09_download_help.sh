node tools/download-multi-day.js --help || true
