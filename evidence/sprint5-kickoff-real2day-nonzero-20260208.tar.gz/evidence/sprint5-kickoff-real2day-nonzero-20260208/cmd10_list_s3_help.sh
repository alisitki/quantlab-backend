node tools/list-s3-data.js --help || true
