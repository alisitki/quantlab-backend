rg -n "adausdt" evidence/sprint5-kickoff-real2day-nonzero-20260208/cmd04_find_all_parquet_meta/stdout.log | head -n 200
