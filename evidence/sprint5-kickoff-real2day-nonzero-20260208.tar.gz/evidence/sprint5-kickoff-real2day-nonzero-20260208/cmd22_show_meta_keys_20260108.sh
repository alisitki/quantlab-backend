node - <<"NODE"
import { readFileSync } from "node:fs";
const m = JSON.parse(readFileSync("data/sprint2/adausdt_20260108_meta.json","utf8"));
console.log(Object.keys(m).sort().join("\n"));
NODE
