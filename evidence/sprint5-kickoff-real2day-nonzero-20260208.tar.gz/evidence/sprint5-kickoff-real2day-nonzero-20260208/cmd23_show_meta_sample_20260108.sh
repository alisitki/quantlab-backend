node - <<"NODE"
import { readFileSync } from "node:fs";
const m = JSON.parse(readFileSync("data/sprint2/adausdt_20260108_meta.json","utf8"));
const pick = {};
for (const k of ["rows","sha256","stream_type","schema_version","symbol","exchange","start_ts","end_ts","source","features","regime","columns","version"]) {
  if (k in m) pick[k]=m[k];
}
console.log(JSON.stringify(pick,null,2));
NODE
