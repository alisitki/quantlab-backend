node - <<'NODE'
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import dotenv from 'dotenv';

dotenv.config();

const s3 = new S3Client({
  endpoint: process.env.S3_COMPACT_ENDPOINT,
  region: 'auto',
  credentials: {
    accessKeyId: process.env.S3_COMPACT_ACCESS_KEY,
    secretAccessKey: process.env.S3_COMPACT_SECRET_KEY,
  },
  forcePathStyle: true,
});

const BUCKET = 'quantlab-compact';

async function readBodyToString(body) {
  const chunks = [];
  for await (const chunk of body) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks).toString('utf8');
}

async function fetchMeta(date) {
  const key = `exchange=binance/stream=bbo/symbol=adausdt/date=${date}/meta.json`;
  const res = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: key }));
  const text = await readBodyToString(res.Body);
  const meta = JSON.parse(text);
  return { date, key, rows: meta.rows ?? null, sha256: meta.sha256 ?? null, stream_type: meta.stream_type ?? null, schema_version: meta.schema_version ?? null };
}

const dates = [
  '20260126','20260127','20260128','20260129','20260130',
  '20260201','20260202','20260203','20260204'
];

for (const d of dates) {
  try {
    const m = await fetchMeta(d);
    console.log([m.date, `rows=${m.rows ?? 'N/A'}`, `sha256=${m.sha256 ?? 'N/A'}`, `stream=${m.stream_type ?? 'N/A'}`, `schema_v=${m.schema_version ?? 'N/A'}`].join('\t'));
  } catch (e) {
    console.log(`${d}\tMETA_MISSING\terr=${e?.name ?? 'Error'}:${e?.message ?? String(e)}`);
  }
}
NODE
