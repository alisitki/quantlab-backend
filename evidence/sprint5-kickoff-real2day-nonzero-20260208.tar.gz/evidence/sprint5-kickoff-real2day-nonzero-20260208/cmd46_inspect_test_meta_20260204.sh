node - <<'NODE'
import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('data/test/adausdt_20260204_meta.json','utf8'));
console.log('keys=' + Object.keys(m).sort().join(','));
console.log('---');
console.log(JSON.stringify(m,null,2));
NODE
