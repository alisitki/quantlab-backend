rg -n "window_ts_event|post_filter_version|DIAGNOSTIC_SLICE" -S core tools scripts | head -n 200
