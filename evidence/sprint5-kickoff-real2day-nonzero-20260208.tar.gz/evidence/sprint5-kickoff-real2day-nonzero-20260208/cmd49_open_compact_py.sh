nl -ba core/compressor/compact.py | sed -n "350,720p"
