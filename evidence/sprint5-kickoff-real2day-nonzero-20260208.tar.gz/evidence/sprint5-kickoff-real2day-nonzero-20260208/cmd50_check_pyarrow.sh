python3 -c "import sys; print(sys.version)"; python3 -c "import pyarrow as pa, pyarrow.parquet as pq; print(pa.__version__)"
