python3 - <<'PY'
import pyarrow.parquet as pq
pf = pq.ParquetFile('data/test/adausdt_20260203.parquet')
md = pf.metadata
print('num_row_groups=', md.num_row_groups)
print('num_rows=', md.num_rows)
print('schema=', md.schema)
# Try to print compression for first few columns in first row group
rg0 = md.row_group(0)
for i in range(min(10, rg0.num_columns)):
    col = rg0.column(i)
    print(f'col[{i}] name={col.path_in_schema} compression={col.compression}')
PY
