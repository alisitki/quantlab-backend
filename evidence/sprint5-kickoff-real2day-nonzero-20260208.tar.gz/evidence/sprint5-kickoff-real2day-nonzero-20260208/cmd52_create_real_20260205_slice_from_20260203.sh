python3 - <<'PY'
import json, hashlib
import pyarrow.dataset as ds
import pyarrow.compute as pc
import pyarrow.parquet as pq

SRC = 'data/test/adausdt_20260203.parquet'
DEST = 'data/test/adausdt_20260205.parquet'
DEST_META = 'data/test/adausdt_20260205_meta.json'

# Existing slice window for 20260204 (from its meta) to avoid overlap
m04 = json.load(open('data/test/adausdt_20260204_meta.json','r',encoding='utf-8'))
base_start = int(m04['diagnostic']['window_ts_event']['endTs']) + 1
window_ms = 600_000  # 10 minutes

dataset = ds.dataset(SRC, format='parquet')

def count_in_window(start_ts, end_ts):
    flt = (ds.field('ts_event') >= start_ts) & (ds.field('ts_event') <= end_ts)
    return dataset.count_rows(filter=flt)

chosen = None
# Try up to 24 windows (4 hours) after the existing slice
for i in range(24):
    start_ts = base_start + i * window_ms
    end_ts = start_ts + window_ms - 1
    n = count_in_window(start_ts, end_ts)
    print(f'candidate_window[{i}] startTs={start_ts} endTs={end_ts} rows={n}')
    if n >= 1000:
        chosen = (start_ts, end_ts, n)
        break

if not chosen:
    raise SystemExit('FATAL: could not find a non-empty 10-minute window with >=1000 rows')

start_ts, end_ts, n = chosen
flt = (ds.field('ts_event') >= start_ts) & (ds.field('ts_event') <= end_ts)

# Materialize the slice
table = dataset.to_table(filter=flt)
# Ensure stable ordering (meta declares ordering_columns ts_event, seq)
table = table.sort_by([('ts_event','ascending'),('seq','ascending')])

# Write parquet (match source compression)
pq.write_table(table, DEST, compression='zstd')

# Compute sha256 of parquet file
h = hashlib.sha256()
with open(DEST,'rb') as f:
    for chunk in iter(lambda: f.read(1024*1024), b''):
        h.update(chunk)
sha = h.hexdigest()

rows = table.num_rows
col = table.column('ts_event')
min_ts = int(pc.min(col).as_py()) if rows else None
max_ts = int(pc.max(col).as_py()) if rows else None

meta = {
  'rows': rows,
  'ts_event_min': min_ts,
  'ts_event_max': max_ts,
  'sha256': sha,
  'source_files': None,
  'schema_version': 1,
  'stream_type': 'bbo',
  'ordering_columns': ['ts_event','seq'],
  'day_quality': 'DIAGNOSTIC_SLICE',
  'post_filter_version': '1.0.0',
  'diagnostic': {
    'source_parquet': SRC,
    'window_ts_event': {'startTs': start_ts, 'endTs': end_ts},
    'note': '10-minute slice created for Sprint-5 acceptance evidence; file date label does not imply timestamp day'
  }
}

with open(DEST_META,'w',encoding='utf-8') as f:
    json.dump(meta, f, indent=2, sort_keys=False)
    f.write('\n')

print('created_parquet=' + DEST)
print('created_meta=' + DEST_META)
print('meta.rows=' + str(rows))
print('meta.sha256=' + sha)
print('meta.ts_event_min=' + str(min_ts))
print('meta.ts_event_max=' + str(max_ts))
PY
