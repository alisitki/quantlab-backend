node - <<'NODE'
import { readFileSync } from 'node:fs';
const m04 = JSON.parse(readFileSync('data/test/adausdt_20260204_meta.json','utf8'));
const m05 = JSON.parse(readFileSync('data/test/adausdt_20260205_meta.json','utf8'));
console.log('20260204.sha256=' + m04.sha256);
console.log('20260205.sha256=' + m05.sha256);
console.log('sha_equal=' + String(m04.sha256 === m05.sha256));
console.log('20260204.rows=' + m04.rows);
console.log('20260205.rows=' + m05.rows);
console.log('20260204.day_quality=' + m04.day_quality);
console.log('20260205.day_quality=' + m05.day_quality);
console.log('20260205.diagnostic.note=' + (m05.diagnostic?.note ?? 'N/A'));
NODE
ls -lh data/test/adausdt_20260204.parquet data/test/adausdt_20260205.parquet data/test/adausdt_20260204_meta.json data/test/adausdt_20260205_meta.json
