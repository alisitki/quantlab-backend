timeout --signal=INT 1200 env DISCOVERY_PERMUTATION_TEST=false NODE_OPTIONS="--max-old-space-size=6144" node tools/run-multi-day-discovery.js \
  --exchange binance --symbol ADA/USDT --stream bbo \
  --start 20260204 --end 20260205 \
  --heapMB 6144 --permutationTest off --mode smoke --progressEvery 1
