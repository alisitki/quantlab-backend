# Sprint-6 Acceptance A1 (perm ON): 20260117..20260118

Goal: Run first real acceptance on FULL(GOOD) window `20260117..20260118` (perm ON default, heap=6144) once and capture `patterns_scanned`, `edges_saved`, and runtime hotspot evidence. Semantics: acceptance unchanged.

Outcome: FAIL (timeout at 1200s; DISCOVERY SUMMARY + report/edges save not reached)

Artifacts (relpath):
- `runs/A1/cmd.sh`
- `runs/A1/stdout.log`
- `runs/A1/stderr.log`
- `runs/A1/time-v.log`
- `runs/A1/exit_code.txt`
- `artifacts/` (empty: report/edges not saved due to timeout)
- `summary.json`

## Permutation / Setup Excerpt (stdout)
```text
permutation_test:  ON (DEFAULT)
[StatisticalEdgeTester] Permutation test: ENABLED (DEFAULT)
```

## PatternScanner / Threshold+Quantile Excerpt (stdout)
```text
[PatternScanner] Running threshold scan (streaming)...
[PatternScanner] Threshold scan completed 3665796 rows
[PatternScanner] Threshold scan found 573 patterns (kept 200)
[PatternScanner] Running quantile scan (streaming)...
[PatternScanner] Quantile scan pass 2: matching patterns...
```

## Runtime Hotspot Excerpt (stdout)
```text
[PatternScanner] Quantile scan pass 2: matching patterns...
[PatternScanner] Quantile scan processed 500000 rows...
[PatternScanner] Quantile scan processed 1000000 rows...
[PatternScanner] Quantile scan processed 1500000 rows...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
```

## DISCOVERY SUMMARY / report_saved / edges_saved

N/A (timeout: exit=124 before summary + artifact save)

## /usr/bin/time -v Summary (time-v.log)
```text
Elapsed (wall clock) time (h:mm:ss or m:ss): 20:00.34
Maximum resident set size (kbytes): 4851132
Exit status: 124
```
