# Sprint-6 Acceptance A1 (perm ON) timeout=3600s: 20260117..20260118

    Intent: Run exactly one acceptance (A1 perm ON default, heap=6144) on FULL(GOOD) window `20260117..20260118` with operational timeout increased `1200s -> 3600s` to reach DISCOVERY SUMMARY and attempt to produce patterns/edges.

    Outcome: FAIL
    Risk note: patterns_scanned=0 => no patterns passed filters; edges_saved not produced

    ## Artifacts (relpath)
    - `runs/A1/cmd.sh`
    - `runs/A1/stdout.log`
    - `runs/A1/stderr.log`
    - `runs/A1/time-v.log`
    - `runs/A1/exit_code.txt`
    - `artifacts/discovery-report.json`
    - `artifacts/` (edges copy: N/A)
    - `summary.json`

    ## Command (runs/A1/cmd.sh)
    ```bash
    set -euo pipefail

timeout --signal=INT 3600 env -u DISCOVERY_PERMUTATION_TEST NODE_OPTIONS="--max-old-space-size=6144" \
  node tools/run-multi-day-discovery.js \
    --exchange binance --symbol ADA/USDT --stream bbo \
    --start 20260117 --end 20260118 \
    --heapMB 6144 \
    --mode acceptance \
    --progressEvery 1
    ```

    ## Permutation Enabled Excerpt (stdout)
    ```text
    permutation_test:  ON (DEFAULT)
[StatisticalEdgeTester] Permutation test: ENABLED (DEFAULT)
    ```

    ## PatternScanner Stage Excerpt (stdout)
    ```text
    [PatternScanner] Running threshold scan (streaming)...
[PatternScanner] Threshold scan completed 3665796 rows
[PatternScanner] Threshold scan found 573 patterns (kept 200)
[PatternScanner] Quantile scan pass 1: collecting feature values...
[PatternScanner] Quantile scan pass 2: matching patterns...
[PatternScanner] Quantile scan pass 2 done: elapsed_ms=565036
[PatternScanner] Quantile scan found 51 patterns (kept 51)
[PatternScanner] Cluster scan pass 1: building feature matrix...
[PatternScanner] Cluster scan pass 2: assigning cluster labels...
[PatternScanner] Cluster scan completed 3665796 rows
[PatternScanner] Cluster scan found 12 patterns (kept 12)
    ```

    ## DISCOVERY SUMMARY (stdout)
    ```text
    ================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     0
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              2228124
================================================================================
    ```

    ## report_saved / edges_saved (stdout)
    ```text
    [Run] report_saved=runs/multi-day-discovery/2026-02-10T15-00-43-761Z_binance_bbo_adausdt_20260117_20260118_acceptance_perm-on/discovery-report-2026-02-10T15-00-43-761Z.json
    [Run] edges_saved=N/A
    ```

    ## /usr/bin/time -v Summary (time-v.log)
    ```text
    Elapsed: mm:ss or m:ss): 37:08.87
    MaxRSS_kB: 4863244
    ExitStatus(time-v): 0
    ExitCode(shell): 0
    ```
