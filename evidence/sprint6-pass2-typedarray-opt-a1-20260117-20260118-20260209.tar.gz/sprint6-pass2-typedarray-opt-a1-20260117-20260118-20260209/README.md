# Sprint-6: Quantile Pass-2 Two-Pass TypedArray Opt (Semantically Exact)

    ## Intent
    Reduce quantile scan pass-2 matching runtime (semantically EXACT) so A1 acceptance on FULL(GOOD) window 20260117..20260118 (perm ON default, heap=6144, timeout=1200s) reaches DISCOVERY SUMMARY.

    ## Scope Lock / Non-goals
    - Only PatternScanner quantile scan pass-2 matching performance optimization.
    - No changes to pattern set/filters/thresholds/report meaning.
    - No timeout increase (still 1200s).
    - Single acceptance verification run (A1 perm ON default).
    - No git commands.

    ## Patch Evidence
    - changed files: `patch/changed_files.txt`
    - code snippet: `patch/snippet.txt`

    ## What Changed (pass-2 matching)
    - Implemented two-pass approach for quantile pass-2:
      - Pass2A: count matches per (feature, horizon, {low,high}) config (clamped to MAX_INDICES_PER_CONFIG)
      - Pass2B: allocate typed arrays sized to match counts and fill deterministically in row order
    - Added timing logs:
      - `[PatternScanner] Quantile pass2A done: elapsed_ms=...`
      - `[PatternScanner] Quantile pass2B done: elapsed_ms=...`

    ## A1 Acceptance (Target)
    Window: 20260117..20260118 (acceptance perm ON)

    Artifacts (relpath):
    - `runs/A1/cmd.sh`
    - `runs/A1/stdout.log`
    - `runs/A1/stderr.log`
    - `runs/A1/time-v.log`
    - `runs/A1/exit_code.txt`
    - `artifacts/` (empty: report/edges not saved due to timeout)
    - `summary.json`

    Result:
    - exit_code: 124
    - pass2A timing line: N/A (not reached)
    - pass2B timing line: N/A (not reached)
    - pass2 done line: N/A (not reached)
    - patterns_scanned: N/A (not produced)
    - report_saved: N/A (not reached)
    - edges_saved: N/A (not reached)

    ## Runtime Hotspot Excerpt (stdout tail)
    ```text
    [Dataset] progress 1/2: date=20260117 parquet=data.parquet meta=meta.json
[Dataset] progress 2/2: date=20260118 parquet=data.parquet meta=meta.json
[Dataset] resolved 2 day(s); meta.rows_total=3685629
[dotenv@17.2.3] injecting env (53) from .env -- tip: 🔄 add secrets lifecycle management: https://dotenvx.com/ops
[dotenv@17.2.3] injecting env (0) from .env -- tip: ⚙️  enable debug logging with { debug: true }

[Run] output_dir=runs/multi-day-discovery/2026-02-10T08-08-19-707Z_binance_bbo_adausdt_20260117_20260118_acceptance_perm-on
[Run] starting EdgeDiscoveryPipeline.runMultiDayStreaming(files=2)...

[StatisticalEdgeTester] Permutation test: ENABLED (DEFAULT)
[StatisticalEdgeTester] Current heap limit: 6192 MB
[StatisticalEdgeTester] Permutation test requires: 6144 MB
[StatisticalEdgeTester] ✅ Heap adequate for permutation test
[EdgeDiscoveryPipeline] ========================================
[EdgeDiscoveryPipeline] Running multi-day discovery (STREAMING) with 2 files
[EdgeDiscoveryPipeline] ========================================
[EdgeDiscoveryPipeline] Step 1: Creating iterator factory...
[DiscoveryDataLoader] Loading multi-day data (streaming): 2 files
[DiscoveryDataLoader] Training regime model on first file (streaming)...
[DiscoveryDataLoader] Collecting regime vectors (streaming)...
{"event":"replay_stats","run_id":"b4dc1ab1-f07c-46ea-9bfe-59a24c5f1dd6","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":93912,"stop_reason":"EOF"}
[DiscoveryDataLoader] Collected 1517699 regime vectors from 1525727 events (8028 warmup)
[DiscoveryDataLoader] Regime model trained: 4 clusters
[DiscoveryDataLoader] Memory: regime vectors GC-able now (1517699 vectors)
[DiscoveryDataLoader] Metadata prepared (totalRowCount: TBD via iterator)
[DiscoveryDataLoader] Iterator factory ready for streaming
[EdgeDiscoveryPipeline] Iterator factory ready. Estimated rows: null
[EdgeDiscoveryPipeline] Step 2: Preparing streaming dataset...
[EdgeDiscoveryPipeline] Dataset ready (streaming mode)
[EdgeDiscoveryPipeline] Step 3: Scanning for patterns...
[PatternScanner] Scanning with methods: threshold, quantile, cluster
[PatternScanner] Mode: STREAMING (async iterator detected)
[PatternScanner] Running threshold scan (streaming)...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet
{"event":"replay_stats","run_id":"d24a11a0-551f-407f-9371-1f0b9d9e0acb","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":113930,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 1517699 rows from 1525727 events (8028 warmup)
[DiscoveryDataLoader] Day streamed: 1517699 rows yielded
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
{"event":"replay_stats","run_id":"1235c92a-d6a9-4cc1-9ce3-248f4b71cb64","manifest_id":"aae65b364ed3","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet","batch_size":10000,"emitted_rows":2159902,"duration_ms":164986,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 2148097 rows from 2159902 events (11805 warmup)
[DiscoveryDataLoader] Day streamed: 2148097 rows yielded
[PatternScanner] Testing 810 threshold configurations...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet
{"event":"replay_stats","run_id":"b4bda7a5-e703-4514-ba1b-214b2116e8c8","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":128324,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 1517699 rows from 1525727 events (8028 warmup)
[PatternScanner] Threshold scan processed 500000 rows...
[PatternScanner] Threshold scan processed 1000000 rows...
[PatternScanner] Threshold scan processed 1500000 rows...
[DiscoveryDataLoader] Day streamed: 1517699 rows yielded
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
{"event":"replay_stats","run_id":"edac785e-95af-46a4-93b4-63c23e8a8afd","manifest_id":"aae65b364ed3","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet","batch_size":10000,"emitted_rows":2159902,"duration_ms":163965,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 2148097 rows from 2159902 events (11805 warmup)
[PatternScanner] Threshold scan processed 2000000 rows...
[PatternScanner] Threshold scan processed 2500000 rows...
[PatternScanner] Threshold scan processed 3000000 rows...
[PatternScanner] Threshold scan processed 3500000 rows...
[DiscoveryDataLoader] Day streamed: 2148097 rows yielded
[PatternScanner] Warning: 261 configs exceeded 50000 matches (capped)
[PatternScanner] Threshold scan completed 3665796 rows
[PatternScanner] Threshold scan found 573 patterns (kept 200)
[PatternScanner] Running quantile scan (streaming)...
[PatternScanner] Quantile scan pass 1: collecting feature values...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet
{"event":"replay_stats","run_id":"2c28899e-7251-49c8-a188-00fce0167d69","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":108214,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 1517699 rows from 1525727 events (8028 warmup)
[DiscoveryDataLoader] Day streamed: 1517699 rows yielded
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
{"event":"replay_stats","run_id":"e21a130e-a437-42d9-9e92-49353799fcec","manifest_id":"aae65b364ed3","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet","batch_size":10000,"emitted_rows":2159902,"duration_ms":166953,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 2148097 rows from 2159902 events (11805 warmup)
[DiscoveryDataLoader] Day streamed: 2148097 rows yielded
[PatternScanner] Computed quantiles for 9 features
[PatternScanner] Quantile scan pass 2: matching patterns...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet
{"event":"replay_stats","run_id":"dc706c3b-15bf-4bc1-813a-33b86dbe35ca","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":105959,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 1517699 rows from 1525727 events (8028 warmup)
[PatternScanner] Quantile scan processed 500000 rows...
[PatternScanner] Quantile scan processed 1000000 rows...
[PatternScanner] Quantile scan processed 1500000 rows...
[DiscoveryDataLoader] Day streamed: 1517699 rows yielded
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
    ```

    ## DISCOVERY SUMMARY
    ```text
    N/A (timeout before summary)
    ```

    ## /usr/bin/time -v Summary (time-v.log)
    ```text
    Elapsed: mm:ss or m:ss): 20:00.32
    MaxRSS_kB: 4134872
    ExitStatus(time-v): 124
    ExitCode(shell): 124
    ```
