# Sprint-6: Quantile Pass-2 Matching Micro-Opt (Semantically Exact)

    ## Intent
    Optimize PatternScanner quantile scan pass-2 matching loop (semantically EXACT) and re-run A1 acceptance on FULL(GOOD) window 20260117..20260118 with timeout=1200s to reach DISCOVERY SUMMARY.

    ## Scope Lock / Non-goals
    - Only micro-opt inside quantile scan pass 2 (matching patterns) + minimal pass-2 timing log.
    - No threshold changes, no filters/thresholds/regimes changes, no output meaning changes.
    - No timeout increase (still 1200s).
    - No git commands.

    ## Patch Evidence
    - changed files: `patch/changed_files.txt`
    - code snippet (hot loop): `patch/snippet.txt`

    ## What Changed (Micro-opt)
    - Removed per-row/per-config string interpolation + Map key construction in pass-2 inner loop.
    - Precomputed `horizonNum` + `forwardKey` per testConfig.
    - Replaced Map-based stats with array-backed `configStats[]` and `insertionOrder[]` to preserve first-match insertion order semantics.
    - Added a neutral timing log line when pass-2 completes: `[PatternScanner] Quantile scan pass 2 done: elapsed_ms=<...>`.

    ## DIAGNOSTIC_SLICE (Semantic-Risk Spot Check)
    Window: 20260204..20260205 (acceptance perm ON)
    - run logs: `runs/DIAG_20260204_20260205/stdout.log`, `runs/DIAG_20260204_20260205/stderr.log`, `runs/DIAG_20260204_20260205/time-v.log`, `runs/DIAG_20260204_20260205/exit_code.txt`

    Pass-2 timing lines (from `runs/DIAG_20260204_20260205/stdout.log`):
    ```text
    [PatternScanner] Quantile scan pass 2: matching patterns...
[PatternScanner] Quantile scan pass 2 done: elapsed_ms=395
    ```

    DISCOVERY SUMMARY excerpt:
    ```text
    ================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          1
patterns_tested_significant:1
edge_candidates_generated: 1
edge_candidates_registered:1
metadata.dataRowCount:     0
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              4671
================================================================================
    ```

    Saved paths (from stdout; source paths may appear):
    ```text
    [Run] report_saved=runs/multi-day-discovery/2026-02-10T05-44-38-553Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/discovery-report-2026-02-10T05-44-38-553Z.json
    [Run] edges_saved=runs/multi-day-discovery/2026-02-10T05-44-38-553Z_binance_bbo_adausdt_20260204_20260205_acceptance_perm-on/edges-discovered-2026-02-10T05-44-38-553Z.json
    ```

    `/usr/bin/time -v` summary (DIAG):
    ```text
    Elapsed: mm:ss or m:ss): 0:05.01
    MaxRSS_kB: 209768
    ExitStatus(time-v): 0
    ExitCode(shell): 0
    ```

    ## A1 Acceptance (Target)
    Window: 20260117..20260118 (acceptance perm ON)
    - run logs: `runs/A1/stdout.log`, `runs/A1/stderr.log`, `runs/A1/time-v.log`, `runs/A1/exit_code.txt`

    Result:
    - exit_code: 124
    - DISCOVERY SUMMARY reached: false
    - patterns_scanned: N/A
    - report_saved: N/A
    - edges_saved: N/A

    Pass-2 lines (from `runs/A1/stdout.log`):
    ```text
    [PatternScanner] Quantile scan pass 2: matching patterns...
    ```

    Hotspot excerpt (threshold -> quantile pass-2 start; from `runs/A1/stdout.log`):
    ```text
    [DiscoveryDataLoader] Day collected: 2148097 rows from 2159902 events (11805 warmup)
[DiscoveryDataLoader] Day streamed: 2148097 rows yielded
[PatternScanner] Testing 810 threshold configurations...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet
{"event":"replay_stats","run_id":"40afcf11-4836-405e-a00c-e1e3fcb33922","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":128044,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 1517699 rows from 1525727 events (8028 warmup)
[PatternScanner] Threshold scan processed 500000 rows...
[PatternScanner] Threshold scan processed 1000000 rows...
[PatternScanner] Threshold scan processed 1500000 rows...
[DiscoveryDataLoader] Day streamed: 1517699 rows yielded
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
{"event":"replay_stats","run_id":"6cf7bb1a-d89c-41c5-a384-9781fbe8cd36","manifest_id":"aae65b364ed3","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet","batch_size":10000,"emitted_rows":2159902,"duration_ms":163235,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 2148097 rows from 2159902 events (11805 warmup)
[PatternScanner] Threshold scan processed 2000000 rows...
[PatternScanner] Threshold scan processed 2500000 rows...
[PatternScanner] Threshold scan processed 3000000 rows...
[PatternScanner] Threshold scan processed 3500000 rows...
[DiscoveryDataLoader] Day streamed: 2148097 rows yielded
[PatternScanner] Warning: 261 configs exceeded 50000 matches (capped)
[PatternScanner] Threshold scan completed 3665796 rows
[PatternScanner] Threshold scan found 573 patterns (kept 200)
[PatternScanner] Running quantile scan (streaming)...
[PatternScanner] Quantile scan pass 1: collecting feature values...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet
{"event":"replay_stats","run_id":"5e93c7d1-6482-471c-bf21-91c3f7b5b4be","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":120384,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 1517699 rows from 1525727 events (8028 warmup)
[DiscoveryDataLoader] Day streamed: 1517699 rows yielded
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
{"event":"replay_stats","run_id":"5a8d414f-6e78-44d9-bdf7-f46c8875dbd9","manifest_id":"aae65b364ed3","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet","batch_size":10000,"emitted_rows":2159902,"duration_ms":164917,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 2148097 rows from 2159902 events (11805 warmup)
[DiscoveryDataLoader] Day streamed: 2148097 rows yielded
[PatternScanner] Computed quantiles for 9 features
[PatternScanner] Quantile scan pass 2: matching patterns...
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet
{"event":"replay_stats","run_id":"3bcbce3e-33ad-4003-970b-96fba20f08ea","manifest_id":"fa495a8b0f91","parquet_path":"data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260117/data.parquet","batch_size":10000,"emitted_rows":1525727,"duration_ms":107750,"stop_reason":"EOF"}
[DiscoveryDataLoader] Day collected: 1517699 rows from 1525727 events (8028 warmup)
[PatternScanner] Quantile scan processed 500000 rows...
[PatternScanner] Quantile scan processed 1000000 rows...
[PatternScanner] Quantile scan processed 1500000 rows...
[DiscoveryDataLoader] Day streamed: 1517699 rows yielded
[DiscoveryDataLoader] Streaming file: data/curated/exchange=binance/stream=bbo/symbol=adausdt/date=20260118/data.parquet
    ```

    `/usr/bin/time -v` summary (A1):
    ```text
    Elapsed: mm:ss or m:ss): 20:00.31
    MaxRSS_kB: 4158372
    ExitStatus(time-v): 124
    ExitCode(shell): 124
    ```

    ## Evidence Tree
    ```text
    patch/
    runs/A1/
    runs/DIAG_20260204_20260205/
    artifacts/ (empty; A1 did not reach report/edges save)
    README.md
    summary.json
    ```
