# Evidence Pack: sprint6-smoke-cap-300s-20260117-20260118-20260209

Status: **PASS** (target: DISCOVERY SUMMARY + patterns_scanned within 300s, smoke-only row-cap)
Risk: Risk: smoke-only row-cap changes smoke semantics; acceptance unaffected by design (mode=acceptance ignores cap).
Window: 20260117..20260118
smokeMaxRowsPerDay: 200000

Artifacts (rel):
- runs/smoke_cap_300s/cmd.sh
- runs/smoke_cap_300s/stdout.log
- runs/smoke_cap_300s/stderr.log
- runs/smoke_cap_300s/time-v.log
- runs/smoke_cap_300s/exit_code.txt
- summary.json

## SmokeCap log excerpt
```text
[SmokeCap] enabled=true maxRowsPerDay=200000
[SmokeCap] date=20260117 rows_used=200000 rows_total=1525727
[SmokeCap] date=20260118 rows_used=200000 rows_total=2159902
```

## DISCOVERY SUMMARY excerpt
```text
================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     0
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              215180
================================================================================
```
