# Sprint-6 Smoke Cap Guard (300s): 20260117..20260118

Goal: Under smoke cap/slice, verify rows actually flow into the pipeline by counting emitted rows and fixing `metadata.dataRowCount` (smoke-only). Acceptance mode is unaffected.

Run: `runs/smoke_guard/` (`--smokeMaxRowsPerDay 200000 --smokeSlice head_tail`, timeout=300s)
Result: PASS (`rows_selected_total=400000`, `rows_emitted_total=397807`, `metadata.dataRowCount=397807`, `exit=0`)

Artifacts (relpath):
- `runs/smoke_guard/cmd.sh`
- `runs/smoke_guard/stdout.log`
- `runs/smoke_guard/stderr.log`
- `runs/smoke_guard/time-v.log`
- `runs/smoke_guard/exit_code.txt`
- `summary.json`

## SmokeCap Excerpt (stdout)
```text
[SmokeCap] enabled=true maxRowsPerDay=200000 slice=head_tail
[SmokeCap] date=20260117 rows_used_head=100000 rows_used_tail=100000 rows_total=1525727
[SmokeCap] date=20260118 rows_used_head=100000 rows_used_tail=100000 rows_total=2159902
```

## SmokeCapGuard Excerpt (stdout)
```text
[SmokeCapGuard] PASS rows_selected_total=400000 rows_emitted_total=397807
```

## DISCOVERY SUMMARY Excerpt (stdout)
```text
================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     397807
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              175956
================================================================================
```
