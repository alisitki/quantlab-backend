set -euo pipefail
timeout --signal=INT 300 env NODE_OPTIONS="--max-old-space-size=6144" \
  node tools/run-multi-day-discovery.js \
    --exchange binance --symbol ADA/USDT --stream bbo \
    --start 20260117 --end 20260118 \
    --heapMB 6144 \
    --mode smoke \
    --smokeMaxRowsPerDay 200000 \
    --smokeSlice head_tail \
    --progressEvery 1
