# Evidence Pack: sprint6-smoke-signal-good2day-lowrows-20260209

Purpose: Sprint-6 FULL(GOOD) 2-day smoke signal via low-rows candidate re-selection (max 3); timeout fixed at 300s.

Status: **FAIL**

Failure reason: smoke_no_discovery_summary_in_top3

Risk note: Risk: timeout=300s appears insufficient for selected FULL(GOOD) low-rows windows under current runner.

FULL definition applied: day_quality==GOOD

## Inventory
- inventory/adausdt_bbo_daily_inventory.tsv
- inventory/adausdt_bbo_daily_inventory_missing_day_quality.tsv

## Candidates (Top3)
- inventory/candidates_ranked_top3.tsv

## Candidate sha256 proof
- sha256/candidate_sha256_proof.txt
- sha256/sha256sum_candidate_parquets.txt

## Smoke runs
- runs/try1/
- runs/try2/
- runs/try3/

## Top3 (Simplified)
```text
rank	start	end	rows_total	day1_rows	day2_rows	sha_equal
1	20260117	20260118	3685629	1525727	2159902	false
2	20260116	20260117	3744041	2218314	1525727	false
3	20260110	20260111	3923697	1728582	2195115	false
```

## Critical stdout blocks

### try1 exit=124

Artifacts:
- runs/try1/cmd.sh
- runs/try1/stdout.log
- runs/try1/time-v.log
- runs/try1/exit_code.txt

DISCOVERY SUMMARY block:
N/A

patterns_scanned line:
N/A

/usr/bin/time -v summary:
```text
Elapsed (wall clock) time (h:mm:ss or m:ss): 5:00.22
	Maximum resident set size (kbytes): 2878148
	Exit status: 124
```

### try2 exit=124

Artifacts:
- runs/try2/cmd.sh
- runs/try2/stdout.log
- runs/try2/time-v.log
- runs/try2/exit_code.txt

DISCOVERY SUMMARY block:
N/A

patterns_scanned line:
N/A

/usr/bin/time -v summary:
```text
Elapsed (wall clock) time (h:mm:ss or m:ss): 5:00.27
	Maximum resident set size (kbytes): 3035872
	Exit status: 124
```

### try3 exit=124

Artifacts:
- runs/try3/cmd.sh
- runs/try3/stdout.log
- runs/try3/time-v.log
- runs/try3/exit_code.txt

DISCOVERY SUMMARY block:
N/A

patterns_scanned line:
N/A

/usr/bin/time -v summary:
```text
Elapsed (wall clock) time (h:mm:ss or m:ss): 5:00.22
	Maximum resident set size (kbytes): 3018956
	Exit status: 124
```
