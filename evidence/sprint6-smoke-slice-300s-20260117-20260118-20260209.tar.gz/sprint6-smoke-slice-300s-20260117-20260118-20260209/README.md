# Sprint-6 Smoke Slice Signal (300s): 20260117..20260118

Goal: In `--mode smoke` (timeout=300s), increase chance of `patterns_scanned > 0` via deterministic per-day slice selection (head_tail / tail). Acceptance mode is unaffected.

Window: `20260117..20260118`
Config: `--smokeMaxRowsPerDay 200000`

Results:
- S1 `head_tail`: `exit=0`, `patterns_scanned=0` (FAIL)
- S2 `tail`: `exit=0`, `patterns_scanned=0` (FAIL)

Artifacts (relpath):
- `runs/S1_head_tail/cmd.sh`
- `runs/S1_head_tail/stdout.log`
- `runs/S1_head_tail/stderr.log`
- `runs/S1_head_tail/time-v.log`
- `runs/S1_head_tail/exit_code.txt`
- `runs/S2_tail/cmd.sh`
- `runs/S2_tail/stdout.log`
- `runs/S2_tail/stderr.log`
- `runs/S2_tail/time-v.log`
- `runs/S2_tail/exit_code.txt`
- `summary.json`

## SmokeCap Excerpt (stdout)

S1 (`runs/S1_head_tail/stdout.log`):
```text
[SmokeCap] enabled=true maxRowsPerDay=200000 slice=head_tail
[SmokeCap] date=20260117 rows_used_head=100000 rows_used_tail=100000 rows_total=1525727
[SmokeCap] date=20260118 rows_used_head=100000 rows_used_tail=100000 rows_total=2159902
```

S2 (`runs/S2_tail/stdout.log`):
```text
[SmokeCap] enabled=true maxRowsPerDay=200000 slice=tail
[SmokeCap] date=20260117 rows_used_head=0 rows_used_tail=200000 rows_total=1525727
[SmokeCap] date=20260118 rows_used_head=0 rows_used_tail=200000 rows_total=2159902
```

## DISCOVERY SUMMARY Excerpts (stdout)

S1 (`runs/S1_head_tail/stdout.log`):
```text
================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     0
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              179465
================================================================================
```

S2 (`runs/S2_tail/stdout.log`):
```text
================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     0
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              170157
================================================================================
```
