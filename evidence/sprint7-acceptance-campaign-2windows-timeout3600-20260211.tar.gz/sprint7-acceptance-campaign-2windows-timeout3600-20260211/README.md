# Sprint-7 Acceptance Campaign (2 windows, timeout=3600)

Intent: FULL(GOOD) real 2 aday window icin kod degistirmeden acceptance (perm ON default) kosup kampanya PASS/FAIL kararini kesinlestirmek.

Campaign Result: FAIL
Risk note: both windows produced patterns_scanned=0 and no edges_saved line

## Runs Table
| run | window | exit | summary_reached | patterns_scanned | edges_saved | wall_s | max_rss_kb | run_pass |
|---|---|---:|---|---:|---|---:|---:|---|
| W1_A1 | 20260117..20260118 | 0 | true | 0 | false | 2032.31 | 5085188 | false |
| W2_A1 | 20260116..20260117 | 0 | true | 0 | false | 2050.82 | 4686592 | false |

## Evidence Relpaths
- runs/W1_A1/cmd.sh
- runs/W1_A1/stdout.log
- runs/W1_A1/stderr.log
- runs/W1_A1/time-v.log
- runs/W1_A1/exit_code.txt
- runs/W2_A1/cmd.sh
- runs/W2_A1/stdout.log
- runs/W2_A1/stderr.log
- runs/W2_A1/time-v.log
- runs/W2_A1/exit_code.txt
- sha256/window1_inputs.txt
- sha256/window2_inputs.txt
- artifacts/W1_A1_discovery-report.json
- artifacts/W2_A1_discovery-report.json
- summary.json

## W1_A1 excerpts
Command relpath: runs/W1_A1/cmd.sh

PatternScanner lines:

```text
25:[StatisticalEdgeTester] Permutation test: ENABLED (DEFAULT)
27:[StatisticalEdgeTester] Permutation test requires: 6144 MB
75:[PatternScanner] Threshold scan found 573 patterns (kept 200)
77:[PatternScanner] Quantile scan pass 1: collecting feature values...
87:[PatternScanner] Quantile scan pass 2: matching patterns...
121:[PatternScanner] Quantile scan pass 2 done: elapsed_ms=526888
122:[PatternScanner] Quantile scan found 51 patterns (kept 51)
160:[PatternScanner] Cluster scan found 12 patterns (kept 12)
```

DISCOVERY SUMMARY excerpt:

```text
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     0
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              2031628
================================================================================
```

Report/edges line status:

```text
report_saved_line_present=true
edges_saved_line_present=false
report_artifact_relpath=artifacts/W1_A1_discovery-report.json
edges_artifact_relpath=N/A
```

Time summary:

```text
wall_s=2032.31
max_rss_kb=5085188
exit_code=0
```

## W2_A1 excerpts
Command relpath: runs/W2_A1/cmd.sh

PatternScanner lines:

```text
25:[StatisticalEdgeTester] Permutation test: ENABLED (DEFAULT)
27:[StatisticalEdgeTester] Permutation test requires: 6144 MB
75:[PatternScanner] Threshold scan found 570 patterns (kept 200)
77:[PatternScanner] Quantile scan pass 1: collecting feature values...
87:[PatternScanner] Quantile scan pass 2: matching patterns...
121:[PatternScanner] Quantile scan pass 2 done: elapsed_ms=529127
122:[PatternScanner] Quantile scan found 51 patterns (kept 51)
160:[PatternScanner] Cluster scan found 12 patterns (kept 12)
```

DISCOVERY SUMMARY excerpt:

```text
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     0
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              2050182
================================================================================
```

Report/edges line status:

```text
report_saved_line_present=true
edges_saved_line_present=false
report_artifact_relpath=artifacts/W2_A1_discovery-report.json
edges_artifact_relpath=N/A
```

Time summary:

```text
wall_s=2050.82
max_rss_kb=4686592
exit_code=0
```
