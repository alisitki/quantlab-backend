# Sprint-7 Smoke Signal: FULL(GOOD) 2-day low-rows top candidates

Intent: code changes olmadan FULL(GOOD) ardışık 2-gün window’lardan low-rows öncelikli max 3 aday seçip smoke-cap+guard (300s) ile patterns_scanned>0 sinyali aramak.

Outcome: FAIL
Risk note: all tries produced patterns_scanned=0 despite SmokeCapGuard PASS

## Evidence Relpaths
- `inventory/adausdt_bbo_daily_inventory.tsv`
- `inventory/candidates_ranked_top3.tsv`
- `sha256/candidate_sha256_proof.txt`
- `runs/try1/cmd.sh`
- `runs/try1/stdout.log`
- `runs/try1/stderr.log`
- `runs/try1/time-v.log`
- `runs/try1/exit_code.txt`
- `runs/try2/cmd.sh`
- `runs/try2/stdout.log`
- `runs/try2/stderr.log`
- `runs/try2/time-v.log`
- `runs/try2/exit_code.txt`
- `summary.json`

## Ranked Candidates (low rows)
| rank | window | rows_total | sha_equal |
|---:|---|---:|---:|
| 1 | 20260117..20260118 | 3685629 | false |
| 2 | 20260116..20260117 | 3744041 | false |

Not: data/curated altında sadece 2 eligible GOOD ardışık 2-gün aday bulundu; try3 yok.

## try1 (20260117..20260118)
Command: `runs/try1/cmd.sh`
SmokeCap + Guard excerpt:
```text
[SmokeCap] enabled=true maxRowsPerDay=200000 slice=head_tail
[SmokeCap] date=20260117 rows_used_head=100000 rows_used_tail=100000 rows_total=1525727
[SmokeCap] date=20260118 rows_used_head=100000 rows_used_tail=100000 rows_total=2159902
[SmokeCapGuard] PASS rows_selected_total=400000 rows_emitted_total=397807
```
DISCOVERY SUMMARY excerpt:
```text
================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     397807
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              160245
================================================================================
```
time -v summary:
```text
Elapsed: 2:40.62
MaxRSS_kB: 1214076
ExitStatus(time-v): 0
ExitCode(shell): 0
```

## try2 (20260116..20260117)
Command: `runs/try2/cmd.sh`
SmokeCap + Guard excerpt:
```text
[SmokeCap] enabled=true maxRowsPerDay=200000 slice=head_tail
[SmokeCap] date=20260116 rows_used_head=100000 rows_used_tail=100000 rows_total=2218314
[SmokeCap] date=20260117 rows_used_head=100000 rows_used_tail=100000 rows_total=1525727
[SmokeCapGuard] PASS rows_selected_total=400000 rows_emitted_total=397440
```
DISCOVERY SUMMARY excerpt:
```text
================================================================================
DISCOVERY SUMMARY
================================================================================
patterns_scanned:          0
patterns_tested_significant:0
edge_candidates_generated: 0
edge_candidates_registered:0
metadata.dataRowCount:     397440
metadata.regimesUsed:      4
metadata.filesLoaded:      2
duration_ms:              158568
================================================================================
```
time -v summary:
```text
Elapsed: 2:38.92
MaxRSS_kB: 1321332
ExitStatus(time-v): 0
ExitCode(shell): 0
```

