#!/usr/bin/env bash
# NOTE: legacy evidence; command line unknown.
# See cmd00_manual/stdout.log for captured combined output.
