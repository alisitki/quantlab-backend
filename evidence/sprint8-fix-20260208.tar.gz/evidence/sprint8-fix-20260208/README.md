# Evidence Pack: sprint8-fix-20260208

Commands index (root cmd*.sh):
- cmd01_read_skill.sh
- cmd02_open_stat_tester_context.sh
- cmd03_open_test_regime_robustness.sh
- cmd04_find_test_signatures.sh
- cmd05_open_test_function.sh
- cmd06_open_pipeline_callsite.sh
- cmd07_find_testBatch_callsites.sh
- cmd08_open_pipeline_array_callsite.sh
- cmd09_open_pipeline_other_callsite.sh
- cmd10_snapshot_before.sh
- cmd11_syntax_check.sh
- cmd12_diff_stat_tester.sh
- cmd13_diff_pipeline.sh
- cmd14_verify_20260204.sh
- cmd15_verify_20260203.sh
- cmd16_search_callers.sh
- cmd17_open_tester_tests.sh
- cmd18_snapshot_test_before.sh
- cmd19_diff_test_file.sh
- cmd20_run_node_test.sh
- cmd21_run_node_test_heap6144.sh

Command directories (root cmd*/):
- cmd01_read_skill/
- cmd02_open_stat_tester_context/
- cmd03_open_test_regime_robustness/
- cmd04_find_test_signatures/
- cmd05_open_test_function/
- cmd06_open_pipeline_callsite/
- cmd07_find_testBatch_callsites/
- cmd08_open_pipeline_array_callsite/
- cmd09_open_pipeline_other_callsite/
- cmd10_snapshot_before/
- cmd11_syntax_check/
- cmd12_diff_stat_tester/
- cmd13_diff_pipeline/
- cmd14_verify_20260204/
- cmd15_verify_20260203/
- cmd16_search_callers/
- cmd17_open_tester_tests/
- cmd18_snapshot_test_before/
- cmd19_diff_test_file/
- cmd20_run_node_test/
- cmd21_run_node_test_heap6144/

Notes: This pack was normalized to the standard layout; some legacy items may not include full /usr/bin/time -v or exit codes.
