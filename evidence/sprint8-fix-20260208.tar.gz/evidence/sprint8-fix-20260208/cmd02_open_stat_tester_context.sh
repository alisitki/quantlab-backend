#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd02_open_stat_tester_context/stdout.log cmd02_open_stat_tester_context/stderr.log cmd02_open_stat_tester_context/time_v.log cmd02_open_stat_tester_context/exit_code.txt (if present)
