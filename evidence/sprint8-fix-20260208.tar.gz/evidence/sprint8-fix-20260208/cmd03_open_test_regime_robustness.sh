#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd03_open_test_regime_robustness/stdout.log cmd03_open_test_regime_robustness/stderr.log cmd03_open_test_regime_robustness/time_v.log cmd03_open_test_regime_robustness/exit_code.txt (if present)
