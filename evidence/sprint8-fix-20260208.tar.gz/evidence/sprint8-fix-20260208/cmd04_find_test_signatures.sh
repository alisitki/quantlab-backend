#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd04_find_test_signatures/stdout.log cmd04_find_test_signatures/stderr.log cmd04_find_test_signatures/time_v.log cmd04_find_test_signatures/exit_code.txt (if present)
