#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd05_open_test_function/stdout.log cmd05_open_test_function/stderr.log cmd05_open_test_function/time_v.log cmd05_open_test_function/exit_code.txt (if present)
