#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd06_open_pipeline_callsite/stdout.log cmd06_open_pipeline_callsite/stderr.log cmd06_open_pipeline_callsite/time_v.log cmd06_open_pipeline_callsite/exit_code.txt (if present)
