#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd09_open_pipeline_other_callsite/stdout.log cmd09_open_pipeline_other_callsite/stderr.log cmd09_open_pipeline_other_callsite/time_v.log cmd09_open_pipeline_other_callsite/exit_code.txt (if present)
