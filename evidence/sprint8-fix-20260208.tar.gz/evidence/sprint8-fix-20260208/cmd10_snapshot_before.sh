#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd10_snapshot_before/stdout.log cmd10_snapshot_before/stderr.log cmd10_snapshot_before/time_v.log cmd10_snapshot_before/exit_code.txt (if present)
