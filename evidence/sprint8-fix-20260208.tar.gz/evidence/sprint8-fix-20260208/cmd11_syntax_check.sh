#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd11_syntax_check/stdout.log cmd11_syntax_check/stderr.log cmd11_syntax_check/time_v.log cmd11_syntax_check/exit_code.txt (if present)
