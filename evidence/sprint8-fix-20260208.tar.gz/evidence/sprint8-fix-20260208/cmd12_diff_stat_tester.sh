#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd12_diff_stat_tester/stdout.log cmd12_diff_stat_tester/stderr.log cmd12_diff_stat_tester/time_v.log cmd12_diff_stat_tester/exit_code.txt (if present)
