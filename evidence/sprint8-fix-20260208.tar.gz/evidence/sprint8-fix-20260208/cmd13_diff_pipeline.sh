#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd13_diff_pipeline/stdout.log cmd13_diff_pipeline/stderr.log cmd13_diff_pipeline/time_v.log cmd13_diff_pipeline/exit_code.txt (if present)
