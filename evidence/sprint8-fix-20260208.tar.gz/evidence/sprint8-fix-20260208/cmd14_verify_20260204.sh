#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd14_verify_20260204/stdout.log cmd14_verify_20260204/stderr.log cmd14_verify_20260204/time_v.log cmd14_verify_20260204/exit_code.txt (if present)
