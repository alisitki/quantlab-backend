#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd16_search_callers/stdout.log cmd16_search_callers/stderr.log cmd16_search_callers/time_v.log cmd16_search_callers/exit_code.txt (if present)
