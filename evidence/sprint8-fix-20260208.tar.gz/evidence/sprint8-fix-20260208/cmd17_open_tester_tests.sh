#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd17_open_tester_tests/stdout.log cmd17_open_tester_tests/stderr.log cmd17_open_tester_tests/time_v.log cmd17_open_tester_tests/exit_code.txt (if present)
