#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd18_snapshot_test_before/stdout.log cmd18_snapshot_test_before/stderr.log cmd18_snapshot_test_before/time_v.log cmd18_snapshot_test_before/exit_code.txt (if present)
