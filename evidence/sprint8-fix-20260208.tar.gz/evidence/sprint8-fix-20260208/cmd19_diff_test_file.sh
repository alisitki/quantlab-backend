#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd19_diff_test_file/stdout.log cmd19_diff_test_file/stderr.log cmd19_diff_test_file/time_v.log cmd19_diff_test_file/exit_code.txt (if present)
