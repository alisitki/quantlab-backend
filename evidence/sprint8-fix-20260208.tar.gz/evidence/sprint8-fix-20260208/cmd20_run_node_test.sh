#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd20_run_node_test/stdout.log cmd20_run_node_test/stderr.log cmd20_run_node_test/time_v.log cmd20_run_node_test/exit_code.txt (if present)
