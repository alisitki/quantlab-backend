#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd21_run_node_test_heap6144/stdout.log cmd21_run_node_test_heap6144/stderr.log cmd21_run_node_test_heap6144/time_v.log cmd21_run_node_test_heap6144/exit_code.txt (if present)
