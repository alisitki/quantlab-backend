# Evidence Pack: sprint8-sweep-20260208

Commands index (root cmd*.sh):
- cmd00_prereq_tools.sh
- cmd01_ls_data_dirs.sh
- cmd01_read_skill.sh
- cmd02_find_parquet.sh
- cmd02_ls_data.sh
- cmd03_find_dates.sh
- cmd03_find_other_symbols.sh
- cmd04_inspect_runner_resolve.sh
- cmd05_inventory_symbol_dates.sh
- cmd06_meta_summary_ada.sh
- cmd07_inspect_timeout_output.sh
- cmd07_smoke_ADA_20260112.sh
- cmd07_sweep_smoke_ADA_20260112.sh
- cmd08_smoke_ADA_20260110.sh
- cmd09_smoke_ADA_20260111.sh
- cmd10_smoke_ADA_20260203.sh
- cmd11_count_parquet.sh
- cmd12_runner_help.sh
- cmd13_download_help.sh
- cmd14_inspect_download_script.sh
- cmd15_smoke_ADA_20260204.sh
- cmd16_inspect_regime_robustness_gate.sh
- cmd17_list_run_dirs.sh

Command directories (root cmd*/):
- cmd00_prereq_tools/
- cmd01_ls_data_dirs/
- cmd01_read_skill/
- cmd02_find_parquet/
- cmd02_ls_data/
- cmd03_find_dates/
- cmd03_find_other_symbols/
- cmd04_inspect_runner_resolve/
- cmd05_inventory_symbol_dates/
- cmd06_meta_summary_ada/
- cmd07_inspect_timeout_output/
- cmd07_smoke_ADA_20260112/
- cmd07_sweep_smoke_ADA_20260112/
- cmd08_smoke_ADA_20260110/
- cmd09_smoke_ADA_20260111/
- cmd10_smoke_ADA_20260203/
- cmd11_count_parquet/
- cmd12_runner_help/
- cmd13_download_help/
- cmd14_inspect_download_script/
- cmd15_smoke_ADA_20260204/
- cmd16_inspect_regime_robustness_gate/
- cmd17_list_run_dirs/

Notes: This pack was normalized to the standard layout; some legacy items may not include full /usr/bin/time -v or exit codes.
