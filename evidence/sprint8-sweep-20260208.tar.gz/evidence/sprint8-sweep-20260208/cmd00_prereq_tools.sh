#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd00_prereq_tools/stdout.log cmd00_prereq_tools/stderr.log cmd00_prereq_tools/time_v.log cmd00_prereq_tools/exit_code.txt (if present)
