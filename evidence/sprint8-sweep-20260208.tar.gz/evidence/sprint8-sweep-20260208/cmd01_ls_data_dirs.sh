#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd01_ls_data_dirs/stdout.log cmd01_ls_data_dirs/stderr.log cmd01_ls_data_dirs/time_v.log cmd01_ls_data_dirs/exit_code.txt (if present)
