#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd02_find_parquet/stdout.log cmd02_find_parquet/stderr.log cmd02_find_parquet/time_v.log cmd02_find_parquet/exit_code.txt (if present)
