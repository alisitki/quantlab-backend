#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd02_ls_data/stdout.log cmd02_ls_data/stderr.log cmd02_ls_data/time_v.log cmd02_ls_data/exit_code.txt (if present)
