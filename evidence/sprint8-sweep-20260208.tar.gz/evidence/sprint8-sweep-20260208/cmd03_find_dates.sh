#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd03_find_dates/stdout.log cmd03_find_dates/stderr.log cmd03_find_dates/time_v.log cmd03_find_dates/exit_code.txt (if present)
