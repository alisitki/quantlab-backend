#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd03_find_other_symbols/stdout.log cmd03_find_other_symbols/stderr.log cmd03_find_other_symbols/time_v.log cmd03_find_other_symbols/exit_code.txt (if present)
