#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd04_inspect_runner_resolve/stdout.log cmd04_inspect_runner_resolve/stderr.log cmd04_inspect_runner_resolve/time_v.log cmd04_inspect_runner_resolve/exit_code.txt (if present)
