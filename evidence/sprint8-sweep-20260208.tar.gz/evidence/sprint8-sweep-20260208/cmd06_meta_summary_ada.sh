#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd06_meta_summary_ada/stdout.log cmd06_meta_summary_ada/stderr.log cmd06_meta_summary_ada/time_v.log cmd06_meta_summary_ada/exit_code.txt (if present)
