#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd07_inspect_timeout_output/stdout.log cmd07_inspect_timeout_output/stderr.log cmd07_inspect_timeout_output/time_v.log cmd07_inspect_timeout_output/exit_code.txt (if present)
