#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd07_sweep_smoke_ADA_20260112/stdout.log cmd07_sweep_smoke_ADA_20260112/stderr.log cmd07_sweep_smoke_ADA_20260112/time_v.log cmd07_sweep_smoke_ADA_20260112/exit_code.txt (if present)
