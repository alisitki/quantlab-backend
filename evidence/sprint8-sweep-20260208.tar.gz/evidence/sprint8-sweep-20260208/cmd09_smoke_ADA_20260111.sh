#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd09_smoke_ADA_20260111/stdout.log cmd09_smoke_ADA_20260111/stderr.log cmd09_smoke_ADA_20260111/time_v.log cmd09_smoke_ADA_20260111/exit_code.txt (if present)
