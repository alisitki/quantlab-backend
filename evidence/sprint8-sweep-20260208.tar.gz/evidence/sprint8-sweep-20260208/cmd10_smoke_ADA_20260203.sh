#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd10_smoke_ADA_20260203/stdout.log cmd10_smoke_ADA_20260203/stderr.log cmd10_smoke_ADA_20260203/time_v.log cmd10_smoke_ADA_20260203/exit_code.txt (if present)
