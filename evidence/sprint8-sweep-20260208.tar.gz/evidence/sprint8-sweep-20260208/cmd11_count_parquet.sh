#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd11_count_parquet/stdout.log cmd11_count_parquet/stderr.log cmd11_count_parquet/time_v.log cmd11_count_parquet/exit_code.txt (if present)
