#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd13_download_help/stdout.log cmd13_download_help/stderr.log cmd13_download_help/time_v.log cmd13_download_help/exit_code.txt (if present)
