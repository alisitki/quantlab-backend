#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd14_inspect_download_script/stdout.log cmd14_inspect_download_script/stderr.log cmd14_inspect_download_script/time_v.log cmd14_inspect_download_script/exit_code.txt (if present)
