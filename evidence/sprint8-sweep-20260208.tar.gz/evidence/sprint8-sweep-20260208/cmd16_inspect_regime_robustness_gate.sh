#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd16_inspect_regime_robustness_gate/stdout.log cmd16_inspect_regime_robustness_gate/stderr.log cmd16_inspect_regime_robustness_gate/time_v.log cmd16_inspect_regime_robustness_gate/exit_code.txt (if present)
