#!/usr/bin/env bash
# NOTE: legacy evidence normalized from flat files; original command line not captured here.
# Logs: cmd17_list_run_dirs/stdout.log cmd17_list_run_dirs/stderr.log cmd17_list_run_dirs/time_v.log cmd17_list_run_dirs/exit_code.txt (if present)
